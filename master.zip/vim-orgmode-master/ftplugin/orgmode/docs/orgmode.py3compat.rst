orgmode.py3compat package
=========================

Submodules
----------

orgmode.py3compat.encode_compatibility module
---------------------------------------------

.. automodule:: orgmode.py3compat.encode_compatibility
    :members:
    :undoc-members:
    :show-inheritance:

orgmode.py3compat.py_py3_string module
--------------------------------------

.. automodule:: orgmode.py3compat.py_py3_string
    :members:
    :undoc-members:
    :show-inheritance:

orgmode.py3compat.unicode_compatibility module
----------------------------------------------

.. automodule:: orgmode.py3compat.unicode_compatibility
    :members:
    :undoc-members:
    :show-inheritance:

orgmode.py3compat.xrange_compatibility module
---------------------------------------------

.. automodule:: orgmode.py3compat.xrange_compatibility
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: orgmode.py3compat
    :members:
    :undoc-members:
    :show-inheritance:
